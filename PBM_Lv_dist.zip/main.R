library(tidyverse)
library(ggplot2)

list <- readr::read_csv("merged_FW-85BU40H1.csv")
# typeof(list)
t1 <- dplyr::as_tibble(list)
lv <- t1$Lv.1
summary(lv)

plot <- function(data) {
 p <- ggplot(data, aes(x=Lv.1, after_stat(density))) + 
    geom_histogram(color="black", fill="white") +
    geom_density(alpha=.2, fill="#FF6666") +
    labs(title="FW-85BU40H1 2Hrs", x="Lv", y="Density") +
    theme(legend.position="none");
  return(p);
}

plot(t1)
summary(lv)

# data <- rnorm(7000, mean=820, sd=18.9);
# t2 <- as_tibble(data)
# # add_column(t2, y=1:7000, before=".value")
# ggplot(t2, aes(x=value, after_stat(density))) + 
#   geom_histogram(color="black", fill="white") +
#   geom_density(alpha=.2, fill="#FF6666") +
#   labs(title="TP65 MP Luminance 2Hrs (Expectation)", x="Lv", y="Density") +
#   theme(legend.position="none")